/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (4-bites számláló gombbal)
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */

#define DEBOUNCING_TRESHOLD 2500

  uint32_t count_debounce = 0;
  uint8_t previous_state_debounce = 0;
  uint8_t current_state_debounce = HAL_GPIO_ReadPin(HMI_BTN_1_GPIO_Port, HMI_BTN_1_Pin);

  uint8_t previous_state_edge = HAL_GPIO_ReadPin(HMI_BTN_1_GPIO_Port, HMI_BTN_1_Pin);
  uint32_t counter = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      count_debounce = 0;

      // 1. Pergésmentesítés: folyamatosan olvassuk a gombot, amíg stabil nem lesz
      while (count_debounce < DEBOUNCING_TRESHOLD)
      {
          previous_state_debounce = current_state_debounce;
          current_state_debounce = HAL_GPIO_ReadPin(HMI_BTN_1_GPIO_Port, HMI_BTN_1_Pin);

          if (previous_state_debounce == current_state_debounce)
          {
              count_debounce++;
          }
          else
          {
              count_debounce = 0; // Ha megváltozik a jel (pergés/zaj), újraindítjuk a számlálást
          }
      }

      // 2. Éldetektálás (felfutó él): ha most be van nyomva (1), de az előbb még nem volt (0)
      if (current_state_debounce == GPIO_PIN_SET && previous_state_edge == GPIO_PIN_RESET)
      {
          counter++; // Számláló léptetése

          // LED-ek frissítése a számláló 4 bitjének megfelelően (MSB -> LSB)
          HAL_GPIO_WritePin(HMI_LED_1_GPIO_Port, HMI_LED_1_Pin, (counter & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
          HAL_GPIO_WritePin(HMI_LED_2_GPIO_Port, HMI_LED_2_Pin, (counter & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
          HAL_GPIO_WritePin(HMI_LED_3_GPIO_Port, HMI_LED_3_Pin, (counter & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
          HAL_GPIO_WritePin(HMI_LED_4_GPIO_Port, HMI_LED_4_Pin, (counter & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
      }

      previous_state_edge = current_state_debounce; // Állapot elmentése a következő ciklusra

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
